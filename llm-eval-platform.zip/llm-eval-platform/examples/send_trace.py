"""How any LLM app reports its calls to the platform for live monitoring.

Example: add this to the AI Customer Support backend after each answer.
"""
import time

import httpx

PLATFORM_URL = "http://localhost:8000"


def report(app: str, model: str, latency_ms: float, input_tokens: int, output_tokens: int, cost_usd: float, ok=True):
    try:
        httpx.post(f"{PLATFORM_URL}/traces", timeout=2, json={
            "app": app, "model": model, "latency_ms": latency_ms, "input_tokens": input_tokens,
            "output_tokens": output_tokens, "cost_usd": cost_usd, "success": ok,
        })
    except httpx.HTTPError:
        pass  # monitoring must never break the app


if __name__ == "__main__":
    start = time.perf_counter()
    time.sleep(0.3)  # pretend this is an LLM call
    report("customer-support", "gpt-4o-mini", (time.perf_counter() - start) * 1000, 350, 90, 0.00011)
    print(httpx.get(f"{PLATFORM_URL}/traces/summary").json())
