"""One interface over OpenAI, Anthropic (Claude), OpenAI-compatible servers (Llama) and a mock model."""
import os
import re
import time
from dataclasses import dataclass

from .config import get_settings, load_model_configs


@dataclass
class Completion:
    text: str
    input_tokens: int
    output_tokens: int
    latency_ms: float
    cost_usd: float


def cost(cfg: dict, input_tokens: int, output_tokens: int) -> float:
    return (input_tokens * cfg["input_price"] + output_tokens * cfg["output_price"]) / 1_000_000


class Provider:
    def __init__(self, name: str, cfg: dict):
        self.name, self.cfg = name, cfg

    async def _call(self, system: str, prompt: str) -> tuple[str, int, int]:
        raise NotImplementedError

    async def complete(self, system: str, prompt: str) -> Completion:
        start = time.perf_counter()
        text, tin, tout = await self._call(system, prompt)
        latency = (time.perf_counter() - start) * 1000
        return Completion(text.strip(), tin, tout, latency, cost(self.cfg, tin, tout))


class OpenAIProvider(Provider):
    def __init__(self, name, cfg, base_url=None, api_key=None):
        super().__init__(name, cfg)
        from openai import AsyncOpenAI

        self.client = AsyncOpenAI(api_key=api_key or get_settings().openai_api_key or "none", base_url=base_url)

    async def _call(self, system, prompt):
        r = await self.client.chat.completions.create(
            model=self.cfg["model"],
            temperature=0,
            messages=[{"role": "system", "content": system}, {"role": "user", "content": prompt}],
        )
        u = r.usage
        return r.choices[0].message.content or "", (u.prompt_tokens if u else 0), (u.completion_tokens if u else 0)


class AnthropicProvider(Provider):
    def __init__(self, name, cfg):
        super().__init__(name, cfg)
        from anthropic import AsyncAnthropic

        self.client = AsyncAnthropic(api_key=get_settings().anthropic_api_key)

    async def _call(self, system, prompt):
        r = await self.client.messages.create(
            model=self.cfg["model"],
            max_tokens=512,
            temperature=0,
            system=system,
            messages=[{"role": "user", "content": prompt}],
        )
        text = "".join(b.text for b in r.content if getattr(b, "type", "") == "text")
        return text, r.usage.input_tokens, r.usage.output_tokens


class MockProvider(Provider):
    """Deterministic offline model: answers with the context sentence that best overlaps the question."""

    async def _call(self, system, prompt):
        context = prompt.split("Context:", 1)[-1].split("Question:", 1)[0]
        question = prompt.split("Question:", 1)[-1]
        q_words = set(re.findall(r"\w+", question.lower()))
        sentences = [s.strip() for s in re.split(r"(?<=[.!?])\s+", context) if s.strip()]
        best = max(sentences, key=lambda s: len(q_words & set(re.findall(r"\w+", s.lower()))), default="")
        text = best if best else "I don't know."
        return text, len(prompt.split()), len(text.split())


def get_provider(name: str) -> Provider:
    configs = load_model_configs()
    if name not in configs:
        raise ValueError(f"Unknown model '{name}'. Available: {', '.join(configs)}")
    cfg = configs[name]
    kind = cfg["provider"]
    if kind == "openai":
        return OpenAIProvider(name, cfg)
    if kind == "anthropic":
        return AnthropicProvider(name, cfg)
    if kind == "openai_compatible":
        base = os.getenv(cfg.get("base_url_env", ""), "") or get_settings().llama_base_url
        return OpenAIProvider(name, cfg, base_url=base, api_key=os.getenv("LLAMA_API_KEY", "ollama"))
    if kind == "mock":
        return MockProvider(name, cfg)
    raise ValueError(f"Unknown provider type {kind}")
