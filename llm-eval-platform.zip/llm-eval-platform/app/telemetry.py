"""Prometheus metrics. Scraped at /prometheus and graphed in Grafana."""
from prometheus_client import Counter, Gauge, Histogram

LLM_REQUESTS = Counter("llm_requests_total", "LLM calls", ["model", "source", "status"])
LLM_LATENCY = Histogram(
    "llm_latency_seconds", "LLM call latency", ["model", "source"],
    buckets=(0.1, 0.25, 0.5, 1, 2, 4, 8, 16, 32),
)
LLM_TOKENS = Counter("llm_tokens_total", "Tokens used", ["model", "source", "direction"])
LLM_COST = Counter("llm_cost_usd_total", "Spend in USD", ["model", "source"])
EVAL_ACCURACY = Gauge("eval_accuracy", "Accuracy of the latest evaluation run", ["model", "dataset"])
EVAL_HALLUCINATION = Gauge("eval_hallucination_rate", "Hallucination rate of latest run", ["model", "dataset"])
EVAL_RUNS = Counter("eval_runs_total", "Evaluation runs", ["status"])


def record_call(model, source, latency_ms, tin, tout, cost_usd, ok=True):
    LLM_REQUESTS.labels(model, source, "ok" if ok else "error").inc()
    if ok:
        LLM_LATENCY.labels(model, source).observe(latency_ms / 1000)
        LLM_TOKENS.labels(model, source, "input").inc(tin)
        LLM_TOKENS.labels(model, source, "output").inc(tout)
        LLM_COST.labels(model, source).inc(cost_usd)
