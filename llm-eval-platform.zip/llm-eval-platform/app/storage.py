"""SQLite storage for evaluation runs, per-question results and production traces."""
import json
import sqlite3
import threading
import time
import uuid

SCHEMA = """
CREATE TABLE IF NOT EXISTS runs (
  id TEXT PRIMARY KEY, dataset TEXT, models TEXT, status TEXT,
  created_at REAL, finished_at REAL, summary TEXT
);
CREATE TABLE IF NOT EXISTS results (
  run_id TEXT, model TEXT, item_id TEXT, question TEXT, answer TEXT, reference TEXT,
  correct INTEGER, hallucination INTEGER, similarity REAL, reason TEXT,
  latency_ms REAL, input_tokens INTEGER, output_tokens INTEGER, cost_usd REAL, error TEXT
);
CREATE TABLE IF NOT EXISTS traces (
  id TEXT PRIMARY KEY, app TEXT, model TEXT, latency_ms REAL, input_tokens INTEGER,
  output_tokens INTEGER, cost_usd REAL, success INTEGER, created_at REAL, metadata TEXT
);
"""


class Storage:
    def __init__(self, path: str):
        self.conn = sqlite3.connect(path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.lock = threading.Lock()
        with self.lock:
            self.conn.executescript(SCHEMA)

    def _exec(self, sql, params=()):
        with self.lock:
            cur = self.conn.execute(sql, params)
            self.conn.commit()
            return cur

    def create_run(self, dataset: str, models: list[str]) -> str:
        run_id = uuid.uuid4().hex[:12]
        self._exec(
            "INSERT INTO runs VALUES (?,?,?,?,?,?,?)",
            (run_id, dataset, json.dumps(models), "running", time.time(), None, None),
        )
        return run_id

    def finish_run(self, run_id: str, summary: dict, status: str = "completed"):
        self._exec(
            "UPDATE runs SET status=?, finished_at=?, summary=? WHERE id=?",
            (status, time.time(), json.dumps(summary), run_id),
        )

    def add_result(self, run_id: str, r: dict):
        cols = [
            "model", "item_id", "question", "answer", "reference", "correct", "hallucination",
            "similarity", "reason", "latency_ms", "input_tokens", "output_tokens", "cost_usd", "error",
        ]
        self._exec(
            f"INSERT INTO results (run_id,{','.join(cols)}) VALUES ({','.join('?' * (len(cols) + 1))})",
            (run_id, *[r.get(c) for c in cols]),
        )

    def get_run(self, run_id: str):
        row = self._exec("SELECT * FROM runs WHERE id=?", (run_id,)).fetchone()
        if not row:
            return None
        run = dict(row)
        run["models"] = json.loads(run["models"])
        run["summary"] = json.loads(run["summary"]) if run["summary"] else None
        return run

    def list_runs(self, limit: int = 50):
        rows = self._exec("SELECT id FROM runs ORDER BY created_at DESC LIMIT ?", (limit,)).fetchall()
        return [self.get_run(r["id"]) for r in rows]

    def get_results(self, run_id: str):
        return [dict(r) for r in self._exec("SELECT * FROM results WHERE run_id=?", (run_id,)).fetchall()]

    def add_trace(self, t: dict) -> str:
        tid = uuid.uuid4().hex[:12]
        self._exec(
            "INSERT INTO traces VALUES (?,?,?,?,?,?,?,?,?,?)",
            (tid, t["app"], t["model"], t["latency_ms"], t["input_tokens"], t["output_tokens"],
             t["cost_usd"], int(t["success"]), time.time(), json.dumps(t.get("metadata", {}))),
        )
        return tid

    def trace_summary(self, app: str | None = None):
        where, params = ("WHERE app=?", (app,)) if app else ("", ())
        row = self._exec(
            f"""SELECT COUNT(*) n, AVG(latency_ms) avg_latency, SUM(cost_usd) total_cost,
                AVG(success) success_rate FROM traces {where}""",
            params,
        ).fetchone()
        return {k: (round(row[k], 4) if isinstance(row[k], float) else row[k]) for k in row.keys()}
