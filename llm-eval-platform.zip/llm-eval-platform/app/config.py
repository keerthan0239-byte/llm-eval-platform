from functools import lru_cache
from pathlib import Path

import yaml
from pydantic_settings import BaseSettings, SettingsConfigDict

ROOT = Path(__file__).resolve().parent.parent


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    openai_api_key: str = ""
    anthropic_api_key: str = ""
    llama_base_url: str = "http://localhost:11434/v1"
    judge_model: str = "gpt-4o-mini"
    database_path: str = "eval.db"
    models_file: str = str(ROOT / "models.yaml")
    max_concurrency: int = 5


@lru_cache
def get_settings() -> Settings:
    return Settings()


@lru_cache
def load_model_configs() -> dict:
    with open(get_settings().models_file) as f:
        return yaml.safe_load(f)["models"]
