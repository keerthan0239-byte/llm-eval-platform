"""FastAPI service: start evaluation runs, compare models, ingest production traces, expose Prometheus metrics."""
import asyncio
import logging

from fastapi import FastAPI, HTTPException, Response
from prometheus_client import CONTENT_TYPE_LATEST, generate_latest
from pydantic import BaseModel, Field

from . import telemetry
from .config import get_settings, load_model_configs
from .runner import list_datasets, load_dataset, run_evaluation
from .storage import Storage

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
app = FastAPI(title="LLM Evaluation & Observability Platform", version="1.0.0")
storage = Storage(get_settings().database_path)
background: set[asyncio.Task] = set()


class RunRequest(BaseModel):
    dataset: str = "customer_support"
    models: list[str] = Field(default_factory=lambda: ["gpt-4o", "claude", "llama"], min_length=1)
    use_judge: bool = True


class Trace(BaseModel):
    app: str
    model: str
    latency_ms: float = Field(ge=0)
    input_tokens: int = Field(0, ge=0)
    output_tokens: int = Field(0, ge=0)
    cost_usd: float = Field(0, ge=0)
    success: bool = True
    metadata: dict = Field(default_factory=dict)


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/models")
def models():
    return {name: {"provider": c["provider"], "model": c["model"]} for name, c in load_model_configs().items()}


@app.get("/datasets")
def datasets():
    return {"datasets": list_datasets()}


@app.post("/runs", status_code=202)
async def start_run(req: RunRequest):
    unknown = [m for m in req.models if m not in load_model_configs()]
    if unknown:
        raise HTTPException(400, f"Unknown models: {unknown}")
    try:
        load_dataset(req.dataset)
    except ValueError as e:
        raise HTTPException(400, str(e))
    run_id = storage.create_run(req.dataset, req.models)
    task = asyncio.create_task(run_evaluation(storage, run_id, req.dataset, req.models, req.use_judge))
    background.add(task)
    task.add_done_callback(lambda t: (background.discard(t), t.exception() if not t.cancelled() else None))
    return {"run_id": run_id, "status": "running"}


@app.get("/runs")
def runs():
    return storage.list_runs()


@app.get("/runs/{run_id}")
def run(run_id: str, include_results: bool = False):
    r = storage.get_run(run_id)
    if not r:
        raise HTTPException(404, "Run not found")
    if include_results:
        r["results"] = storage.get_results(run_id)
    return r


@app.get("/runs/{run_id}/leaderboard")
def leaderboard(run_id: str, sort_by: str = "accuracy"):
    r = storage.get_run(run_id)
    if not r or not r["summary"] or "error" in r["summary"]:
        raise HTTPException(404, "No completed summary for this run")
    reverse = sort_by not in ("hallucination_rate", "avg_latency_ms", "p95_latency_ms", "total_cost_usd")
    rows = [{"model": m, **s} for m, s in r["summary"].items()]
    return sorted(rows, key=lambda x: x.get(sort_by, 0), reverse=reverse)


@app.post("/traces", status_code=201)
def ingest_trace(t: Trace):
    """Any LLM app (e.g. the AI customer support system) can POST each LLM call here for monitoring."""
    telemetry.record_call(t.model, t.app, t.latency_ms, t.input_tokens, t.output_tokens, t.cost_usd, t.success)
    return {"id": storage.add_trace(t.model_dump())}


@app.get("/traces/summary")
def trace_summary(app_name: str | None = None):
    return storage.trace_summary(app_name)


@app.get("/prometheus")
def prometheus():
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)
