"""Run an evaluation from the terminal and print a comparison table.

Example:  python -m app.cli --dataset customer_support --models gpt-4o claude llama
"""
import argparse
import asyncio

from .config import get_settings
from .runner import run_evaluation
from .storage import Storage


def main():
    p = argparse.ArgumentParser(description="Evaluate LLMs on a dataset")
    p.add_argument("--dataset", default="customer_support")
    p.add_argument("--models", nargs="+", default=["mock"])
    p.add_argument("--no-judge", action="store_true", help="use heuristic scoring instead of an LLM judge")
    a = p.parse_args()

    storage = Storage(get_settings().database_path)
    run_id = storage.create_run(a.dataset, a.models)
    summary = asyncio.run(run_evaluation(storage, run_id, a.dataset, a.models, use_judge=not a.no_judge))

    header = f"{'Model':<14}{'Accuracy':>10}{'Halluc.':>10}{'Avg ms':>10}{'p95 ms':>10}{'Cost $':>12}{'Errors':>8}"
    print(f"\nRun {run_id} on '{a.dataset}'\n" + header + "\n" + "-" * len(header))
    for m, s in sorted(summary.items(), key=lambda kv: -kv[1]["accuracy"]):
        print(f"{m:<14}{s['accuracy']:>10.1%}{s['hallucination_rate']:>10.1%}{s['avg_latency_ms']:>10.0f}"
              f"{s['p95_latency_ms']:>10.0f}{s['total_cost_usd']:>12.5f}{s['errors']:>8}")


if __name__ == "__main__":
    main()
