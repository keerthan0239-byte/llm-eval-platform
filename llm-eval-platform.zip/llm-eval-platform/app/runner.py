"""Evaluation pipeline: run every dataset item through every model, score it, and summarize."""
import asyncio
import json
import logging
import statistics
from pathlib import Path

from . import telemetry
from .config import ROOT, get_settings
from .metrics import ANSWER_SYSTEM, JUDGE_PROMPT, JUDGE_SYSTEM, build_prompt, fuzzy_score, heuristic_judge, parse_judge
from .providers import Provider, get_provider
from .storage import Storage

log = logging.getLogger(__name__)
DATASET_DIR = ROOT / "datasets"


def load_dataset(name: str) -> list[dict]:
    path = (DATASET_DIR / f"{name}.jsonl").resolve()
    if DATASET_DIR.resolve() not in path.parents or not path.exists():
        raise ValueError(f"Dataset '{name}' not found")
    items = [json.loads(line) for line in path.read_text().splitlines() if line.strip()]
    for i, item in enumerate(items):
        missing = {"question", "reference"} - item.keys()
        if missing:
            raise ValueError(f"Item {i} missing fields {missing}")
        item.setdefault("id", str(i))
        item.setdefault("context", "")
    return items


def list_datasets() -> list[str]:
    return sorted(p.stem for p in DATASET_DIR.glob("*.jsonl"))


async def judge(judge_provider: Provider | None, item: dict, answer: str) -> dict:
    if judge_provider is None:
        return heuristic_judge(answer, item["reference"], item["context"])
    prompt = JUDGE_PROMPT.format(
        context=item["context"], question=item["question"], reference=item["reference"], answer=answer
    )
    try:
        out = await judge_provider.complete(JUDGE_SYSTEM, prompt)
        return parse_judge(out.text)
    except Exception as e:
        log.warning("Judge failed (%s); using heuristic", e)
        return heuristic_judge(answer, item["reference"], item["context"])


async def evaluate_item(provider, judge_provider, item, sem) -> dict:
    async with sem:
        base = {"model": provider.name, "item_id": item["id"], "question": item["question"], "reference": item["reference"]}
        try:
            out = await provider.complete(ANSWER_SYSTEM, build_prompt(item["question"], item["context"]))
        except Exception as e:
            telemetry.record_call(provider.name, "eval", 0, 0, 0, 0, ok=False)
            return {**base, "error": str(e)[:300], "correct": 0, "hallucination": 0}
        telemetry.record_call(provider.name, "eval", out.latency_ms, out.input_tokens, out.output_tokens, out.cost_usd)
        verdict = await judge(judge_provider, item, out.text)
        return {
            **base,
            "answer": out.text,
            "similarity": fuzzy_score(out.text, item["reference"]),
            "latency_ms": round(out.latency_ms, 1),
            "input_tokens": out.input_tokens,
            "output_tokens": out.output_tokens,
            "cost_usd": round(out.cost_usd, 6),
            **verdict,
        }


def summarize(results: list[dict]) -> dict:
    by_model: dict[str, list[dict]] = {}
    for r in results:
        by_model.setdefault(r["model"], []).append(r)
    summary = {}
    for model, rows in by_model.items():
        ok = [r for r in rows if not r.get("error")]
        lat = sorted(r["latency_ms"] for r in ok)
        summary[model] = {
            "items": len(rows),
            "errors": len(rows) - len(ok),
            "accuracy": round(sum(r["correct"] for r in ok) / len(ok), 3) if ok else 0,
            "hallucination_rate": round(sum(r["hallucination"] for r in ok) / len(ok), 3) if ok else 0,
            "avg_similarity": round(statistics.mean(r["similarity"] for r in ok), 3) if ok else 0,
            "avg_latency_ms": round(statistics.mean(lat), 1) if lat else 0,
            "p95_latency_ms": round(lat[max(0, int(len(lat) * 0.95) - 1)], 1) if lat else 0,
            "total_cost_usd": round(sum(r["cost_usd"] for r in ok), 6),
            "total_tokens": sum(r["input_tokens"] + r["output_tokens"] for r in ok),
        }
    return summary


async def run_evaluation(storage: Storage, run_id: str, dataset: str, models: list[str], use_judge: bool = True) -> dict:
    try:
        items = load_dataset(dataset)
        providers = [get_provider(m) for m in models]
        judge_provider = None
        if use_judge and get_settings().openai_api_key:
            judge_provider = get_provider(get_settings().judge_model)
        sem = asyncio.Semaphore(get_settings().max_concurrency)
        tasks = [evaluate_item(p, judge_provider, item, sem) for p in providers for item in items]
        results = await asyncio.gather(*tasks)
        for r in results:
            storage.add_result(run_id, r)
        summary = summarize(results)
        for model, s in summary.items():
            telemetry.EVAL_ACCURACY.labels(model, dataset).set(s["accuracy"])
            telemetry.EVAL_HALLUCINATION.labels(model, dataset).set(s["hallucination_rate"])
        storage.finish_run(run_id, summary)
        telemetry.EVAL_RUNS.labels("completed").inc()
        return summary
    except Exception as e:
        log.exception("Run %s failed", run_id)
        storage.finish_run(run_id, {"error": str(e)}, status="failed")
        telemetry.EVAL_RUNS.labels("failed").inc()
        raise
