"""Scoring: accuracy (fuzzy + LLM judge), hallucination / faithfulness to context."""
import json
import re

from rapidfuzz import fuzz

ANSWER_SYSTEM = (
    "You are a helpful assistant. Answer the question using ONLY the context. "
    "If the context does not contain the answer, say the information is not available. Be brief."
)

JUDGE_SYSTEM = "You are a strict evaluator of AI answers. Respond with JSON only."

JUDGE_PROMPT = """Context:
{context}

Question: {question}
Reference answer: {reference}
Model answer: {answer}

Score the model answer:
- "correct": 1 if it matches the meaning of the reference answer, else 0
- "hallucination": 1 if it states any fact NOT supported by the context, else 0
- "reason": one short sentence

Return JSON like {{"correct": 1, "hallucination": 0, "reason": "..."}}"""


def build_prompt(question: str, context: str) -> str:
    return f"Context:\n{context}\n\nQuestion: {question}"


def normalize(text: str) -> str:
    return " ".join(re.findall(r"\w+", text.lower()))


def fuzzy_score(answer: str, reference: str) -> float:
    """0-1 similarity that tolerates rewording and extra words."""
    return round(fuzz.token_set_ratio(normalize(answer), normalize(reference)) / 100, 3)


def unsupported_numbers(answer: str, context: str) -> list[str]:
    """Cheap hallucination signal: numbers in the answer that never appear in the context."""
    ctx = set(re.findall(r"\d+(?:\.\d+)?", context))
    return [n for n in re.findall(r"\d+(?:\.\d+)?", answer) if n not in ctx]


def parse_judge(text: str) -> dict:
    match = re.search(r"\{.*\}", text, re.S)
    if not match:
        raise ValueError("Judge did not return JSON")
    data = json.loads(match.group(0))
    return {
        "correct": int(bool(data.get("correct"))),
        "hallucination": int(bool(data.get("hallucination"))),
        "reason": str(data.get("reason", ""))[:300],
    }


def heuristic_judge(answer: str, reference: str, context: str) -> dict:
    """Used when no judge model is available (offline / tests)."""
    score = fuzzy_score(answer, reference)
    bad_numbers = unsupported_numbers(answer, context)
    return {
        "correct": int(score >= 0.6),
        "hallucination": int(bool(bad_numbers)),
        "reason": f"heuristic: similarity {score}" + (f", unsupported numbers {bad_numbers}" if bad_numbers else ""),
    }
