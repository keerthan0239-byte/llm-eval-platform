import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
os.environ["DATABASE_PATH"] = ":memory:"
os.environ["OPENAI_API_KEY"] = ""  # force heuristic judge: tests never call real APIs
