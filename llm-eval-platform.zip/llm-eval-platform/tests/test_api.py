import time

from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)


def test_models_and_datasets():
    assert "gpt-4o" in client.get("/models").json()
    assert "customer_support" in client.get("/datasets").json()["datasets"]


def test_full_eval_run_with_mock_model():
    with TestClient(app) as c:
        r = c.post("/runs", json={"dataset": "customer_support", "models": ["mock"], "use_judge": False})
        assert r.status_code == 202
        run_id = r.json()["run_id"]
        for _ in range(50):
            run = c.get(f"/runs/{run_id}").json()
            if run["status"] != "running":
                break
            time.sleep(0.05)
        assert run["status"] == "completed"
        s = run["summary"]["mock"]
        assert s["items"] == 10 and s["errors"] == 0
        assert s["accuracy"] >= 0.5
        board = c.get(f"/runs/{run_id}/leaderboard").json()
        assert board[0]["model"] == "mock"
        assert len(c.get(f"/runs/{run_id}?include_results=true").json()["results"]) == 10
        assert "eval_accuracy" in c.get("/prometheus").text


def test_rejects_unknown_model_and_dataset():
    assert client.post("/runs", json={"models": ["nope"]}).status_code == 400
    assert client.post("/runs", json={"dataset": "../secret", "models": ["mock"]}).status_code == 400


def test_trace_ingestion():
    r = client.post("/traces", json={"app": "support-bot", "model": "gpt-4o-mini", "latency_ms": 420,
                                     "input_tokens": 300, "output_tokens": 80, "cost_usd": 0.0001})
    assert r.status_code == 201
    s = client.get("/traces/summary", params={"app_name": "support-bot"}).json()
    assert s["n"] >= 1
    assert client.post("/traces", json={"app": "x", "model": "y", "latency_ms": -1}).status_code == 422
    assert 'llm_requests_total{model="gpt-4o-mini",source="support-bot",status="ok"}' in client.get("/prometheus").text
