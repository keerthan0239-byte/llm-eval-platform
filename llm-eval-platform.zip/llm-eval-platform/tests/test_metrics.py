from app.metrics import fuzzy_score, heuristic_judge, parse_judge, unsupported_numbers


def test_fuzzy_score_tolerates_rewording():
    assert fuzzy_score("Standard shipping takes 5-7 business days.", "standard shipping takes 5-7 business days") == 1.0
    assert fuzzy_score("Pizza is tasty", "Refunds within 30 days") < 0.5


def test_unsupported_numbers_flags_hallucinated_facts():
    assert unsupported_numbers("Returns within 45 days", "Returns within 30 days") == ["45"]
    assert unsupported_numbers("Returns within 30 days", "Returns within 30 days") == []


def test_heuristic_judge():
    v = heuristic_judge("Express costs $25.", "Express shipping costs $15.", "Express shipping costs $15.")
    assert v["hallucination"] == 1


def test_parse_judge_handles_extra_text():
    v = parse_judge('Sure! {"correct": 1, "hallucination": 0, "reason": "matches"}')
    assert v == {"correct": 1, "hallucination": 0, "reason": "matches"}
